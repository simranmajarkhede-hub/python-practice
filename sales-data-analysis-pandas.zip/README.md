# Sales Data Analysis Using Python Pandas

A Python-based data analysis project that analyzes sales data using the Pandas library — calculating revenue, average prices, city-wise sales, and identifying best-selling products.

## 🛠️ Technologies Used
- Python
- Pandas
- CSV Files

## ✨ Features
- Imported and cleaned sales data from CSV
- Created a `Total Sales` column (Price × Quantity)
- Calculated total revenue
- Calculated average product price
- Performed city-wise sales analysis using `groupby()`
- Identified the best-selling product (by quantity and by revenue)
- Exported the final report to a CSV file

## 📂 Project Structure
```
sales-data-analysis-pandas/
├── sales_data.csv       # Sample raw sales data (input)
├── sales_analysis.py    # Main analysis script
├── sales_report.csv     # Generated summary report (output)
└── README.md
```

## ▶️ How to Run
1. Make sure Python 3 and Pandas are installed:
   ```bash
   pip install pandas
   ```
2. Run the script:
   ```bash
   python sales_analysis.py
   ```
3. The script prints a summary to the console and generates `sales_report.csv`.

## 📊 Sample Output
```
Total Revenue: 59,451.00
Average Product Price: 1,479.00

City-wise Sales (Total Revenue):
Delhi        17488.0
Bangalore    14590.0
Mumbai       11886.0
Pune          9993.0
Chennai       5494.0

Top product by quantity: Wireless Mouse (18 units)
Top product by revenue: Mechanical Keyboard (11,996.00)
```

## 📚 Skills Demonstrated
- Data Cleaning
- Data Analysis
- Data Aggregation
- Pandas DataFrame Operations
- CSV File Handling

## 💼 Resume Entry
```
Sales Data Analysis Using Python Pandas

• Developed a sales data analysis project using Python and Pandas.
• Performed revenue calculations, city-wise sales analysis, and product performance analysis.
• Used DataFrames, groupby(), filtering, sorting, and CSV file handling.
• Generated a final sales report for analysis.
```
