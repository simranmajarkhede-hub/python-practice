"""
Sales Data Analysis Using Python Pandas
----------------------------------------
Reads raw sales data from a CSV file, cleans/enriches it, and performs
several analyses:
  - Adds a 'Total Sales' column (Price * Quantity)
  - Calculates total revenue
  - Calculates average product price
  - Performs city-wise sales analysis using groupby()
  - Identifies the best-selling product (by quantity and by revenue)
  - Exports a final summary report to a CSV file

Usage:
    python sales_analysis.py
"""

import pandas as pd

INPUT_FILE = "sales_data.csv"
OUTPUT_FILE = "sales_report.csv"


def load_data(path: str) -> pd.DataFrame:
    """Load sales data from CSV and do basic cleaning."""
    df = pd.read_csv(path)

    # Basic data cleaning
    df.drop_duplicates(inplace=True)
    df.dropna(subset=["Product", "Price", "Quantity", "City"], inplace=True)
    df["Price"] = df["Price"].astype(float)
    df["Quantity"] = df["Quantity"].astype(int)

    return df


def enrich_data(df: pd.DataFrame) -> pd.DataFrame:
    """Add a Total Sales column (Price * Quantity)."""
    df["Total Sales"] = df["Price"] * df["Quantity"]
    return df


def calculate_total_revenue(df: pd.DataFrame) -> float:
    return df["Total Sales"].sum()


def calculate_average_price(df: pd.DataFrame) -> float:
    return df["Price"].mean()


def city_wise_sales(df: pd.DataFrame) -> pd.Series:
    """Total sales revenue grouped by city, sorted descending."""
    return df.groupby("City")["Total Sales"].sum().sort_values(ascending=False)


def best_selling_product(df: pd.DataFrame) -> pd.Series:
    """Product with the highest total quantity sold."""
    qty_by_product = df.groupby("Product")["Quantity"].sum().sort_values(ascending=False)
    return qty_by_product


def top_revenue_product(df: pd.DataFrame) -> pd.Series:
    """Product that generated the most revenue."""
    revenue_by_product = df.groupby("Product")["Total Sales"].sum().sort_values(ascending=False)
    return revenue_by_product


def build_report(df: pd.DataFrame) -> pd.DataFrame:
    """Combine all analyses into a single summary DataFrame for export."""
    total_revenue = calculate_total_revenue(df)
    avg_price = calculate_average_price(df)
    city_sales = city_wise_sales(df)
    qty_by_product = best_selling_product(df)
    revenue_by_product = top_revenue_product(df)

    rows = []
    rows.append(["Total Revenue", "", round(total_revenue, 2)])
    rows.append(["Average Product Price", "", round(avg_price, 2)])
    rows.append(["Best-Selling Product (by quantity)", qty_by_product.index[0], int(qty_by_product.iloc[0])])
    rows.append(["Top Revenue Product", revenue_by_product.index[0], round(revenue_by_product.iloc[0], 2)])
    rows.append(["", "", ""])
    rows.append(["--- City-wise Sales ---", "", ""])
    for city, sales in city_sales.items():
        rows.append(["City Sales", city, round(sales, 2)])
    rows.append(["", "", ""])
    rows.append(["--- Product-wise Quantity Sold ---", "", ""])
    for product, qty in qty_by_product.items():
        rows.append(["Product Quantity", product, int(qty)])

    report_df = pd.DataFrame(rows, columns=["Metric", "Detail", "Value"])
    return report_df


def main():
    df = load_data(INPUT_FILE)
    df = enrich_data(df)

    total_revenue = calculate_total_revenue(df)
    avg_price = calculate_average_price(df)
    city_sales = city_wise_sales(df)
    qty_by_product = best_selling_product(df)
    revenue_by_product = top_revenue_product(df)

    print("=" * 50)
    print("SALES DATA ANALYSIS REPORT")
    print("=" * 50)
    print(f"Total Revenue: {total_revenue:,.2f}")
    print(f"Average Product Price: {avg_price:,.2f}")
    print()
    print("City-wise Sales (Total Revenue):")
    print(city_sales.to_string())
    print()
    print("Best-Selling Product (by quantity sold):")
    print(qty_by_product.to_string())
    print()
    print(f"Top product by quantity: {qty_by_product.index[0]} ({int(qty_by_product.iloc[0])} units)")
    print(f"Top product by revenue: {revenue_by_product.index[0]} ({revenue_by_product.iloc[0]:,.2f})")
    print("=" * 50)

    report_df = build_report(df)
    report_df.to_csv(OUTPUT_FILE, index=False)
    print(f"\nFinal report exported to '{OUTPUT_FILE}'")


if __name__ == "__main__":
    main()
